#ifndef DELAY_H
#define DELAY_H
extern void Delay(uint32_t dlyTicks);                //function definition for Delay

#endif
